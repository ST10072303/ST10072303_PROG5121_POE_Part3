
package part3;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author phineas
 */
public class Part3Test {
    
    public Part3Test() {
    }

    @Test
    public void testSomeMethod() {
        Part3 part3 = new Part3();
        String expected = null ;
        String actual = null ;
     assertEquals(expected, actual);
    
    }
    
}
