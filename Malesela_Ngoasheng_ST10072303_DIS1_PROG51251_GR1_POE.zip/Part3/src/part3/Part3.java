/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package part3;
import java.util.ArrayList;
import java.util.Arrays;
/**
 *
 * @author phineas
 */
public class Part3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Populating Arrays [0][1][2][3]
    
    ArrayList<String> developer = 
            new ArrayList<>(Arrays.asList("Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer")); 
    
    ArrayList<String> taskName = new ArrayList<>(Arrays.asList("Create Login", "Creat Add Feature", "Create Report", "Add Arrays"));
    
    ArrayList<String> taskStatus = new ArrayList<>(Arrays.asList("ToDo", "Doing", "Done", "ToDo"));
    
    ArrayList<Integer> taskID = new ArrayList<>(Arrays.asList(001,002,003,004));
  
    ArrayList<Integer> duration = new ArrayList<>(Arrays.asList(5, 8, 2, 11));
     
        System.out.println("Developer, Task Name and Task Duration with the status of done.");
        System.out.println(developer.get(2) + taskName.get(2) + duration.get(2));     //task with status done
        System.out.println("");
        System.out.println("Developer and duration of the Class with longest duration");
        System.out.println(developer.get(3) + duration.get(3));                       //class with longest duration
        System.out.println("");                                         
        System.out.println("a report of all captured tasks");
        System.out.println(taskName);                                                 //display report of captured tasks
   
        taskName.remove("Item");                                                      //Delete a task using the Task Name
        
          //Searching for all tasks assigned to a developer and display the Task Name and Task Status
      if (developer.contains("Mike Smith" + "Edward Harrison" + "Samantha Paulson" + "Glenda Oberholzer")){
          System.out.println(taskName.get(0) + taskName.get(1) + taskName.get(2) + taskName.get(3));
          System.out.println(taskStatus.get(0) + taskStatus.get(1) + taskStatus.get(2) + taskStatus.get(3));
      } else {
          System.out.println("Developer not found");
      }
    }
    
}
